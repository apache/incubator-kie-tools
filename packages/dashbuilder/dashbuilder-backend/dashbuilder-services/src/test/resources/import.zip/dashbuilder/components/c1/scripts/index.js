function imageClicked() {
    alert("Dashbuilder logo!");
}
