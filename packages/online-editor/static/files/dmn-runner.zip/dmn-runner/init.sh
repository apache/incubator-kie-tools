java -jar jitexecutor-dmnexecutor-2.0.0-SNAPSHOT-runner.jar

